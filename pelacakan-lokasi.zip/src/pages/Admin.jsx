import React, { useEffect, useState } from 'react';
import { db } from '../firebase';
import { ref, onValue } from 'firebase/database';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

function Admin() {
  const [locations, setLocations] = useState({});

  useEffect(() => {
    const locRef = ref(db, 'locations');
    const unsubscribe = onValue(locRef, (snapshot) => {
      const data = snapshot.val();
      setLocations(data || {});
    });
    return () => unsubscribe();
  }, []);

  return (
    <div className="h-screen">
      <MapContainer center={[-6.2, 106.8]} zoom={13} style={{ height: '100%', width: '100%' }}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        {Object.entries(locations).map(([uid, loc]) => (
          <Marker key={uid} position={[loc.lat, loc.lng]} icon={L.icon({ iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png', iconSize: [25, 41] })}>
            <Popup>
              <div>
                <p><strong>User:</strong> {uid}</p>
                <p><strong>Time:</strong> {new Date(loc.timestamp).toLocaleString()}</p>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}

export default Admin;
