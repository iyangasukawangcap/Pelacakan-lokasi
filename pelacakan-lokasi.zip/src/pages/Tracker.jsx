import React, { useEffect } from 'react';
import { db, auth } from '../firebase';
import { ref, set } from 'firebase/database';
import { useNavigate } from 'react-router-dom';
import { MapContainer, TileLayer, Marker, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

const UpdateMap = ({ lat, lng }) => {
  const map = useMap();
  useEffect(() => {
    map.setView([lat, lng], 15);
  }, [lat, lng]);
  return null;
};

function Tracker() {
  const navigate = useNavigate();

  useEffect(() => {
    const watchId = navigator.geolocation.watchPosition((position) => {
      const { latitude, longitude } = position.coords;
      const uid = auth.currentUser?.uid;
      if (uid) {
        set(ref(db, `locations/${uid}`), {
          lat: latitude,
          lng: longitude,
          timestamp: Date.now()
        });
      }
    });

    return () => navigator.geolocation.clearWatch(watchId);
  }, []);

  return (
    <div className="h-screen">
      <MapContainer center={[-6.2, 106.8]} zoom={13} style={{ height: '100%', width: '100%' }}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <Marker position={[-6.2, 106.8]} icon={L.icon({ iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png', iconSize: [25, 41] })} />
        <UpdateMap lat={-6.2} lng={106.8} />
      </MapContainer>
    </div>
  );
}

export default Tracker;
